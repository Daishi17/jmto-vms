<div class="container-fluid">
  <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
    <div class="col-md-4 d-flex align-items-center">
      <a href="/" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1">
        <img src="<?php echo base_url();?>/assets/brand/bootstrap-logo.svg" alt="" width="29" height="24" class="d-inline-block align-text-top">
      </a>
      <span class="mb-3 mb-md-0 text-muted">Copy Right &copy; 2023 <b>Procurement, JMTO</b></span>
    </div>

    <div class="nav col-md-4 justify-content-end list-unstyled d-flex">
        <span class="mb-3 mb-md-0 text-muted">[ Version. 1.0 ]<b> E-RegisDrtJMTO</b></span>
    </div>
  </footer><hr>
</div>