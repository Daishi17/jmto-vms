
<!-- global  -->
<input type="hidden" value="<?= base_url('datapenyedia/get_row_global_vendor/') ?>" name="url_get_row_vendor">

<!-- link post nib -->
<!-- nib -->
<input type="hidden" name="url_dekrip_nib" value="<?= base_url('datapenyedia/dekrip_nib') ?>">
<input type="hidden" name="url_encryption_nib" value="<?= base_url('datapenyedia/encryption_nib/') ?>">
<input type="hidden" name="url_download_nib" value="<?= base_url('datapenyedia/url_download_nib/') ?>">
<input type="hidden" value="<?= base_url('datapenyedia/add_nib') ?>" name="url_post_nib">
<!-- kbli nib-->
<input type="hidden" name="url_tambah_kbli_nib" value="<?= base_url('datapenyedia/tambah_kbli_nib') ?>">
<input type="hidden" name="url_table_kbli_nib" value="<?= base_url('datapenyedia/get_data_kbli_nib') ?>">
<input type="hidden" name="url_byid_kbli_nib" value="<?= base_url('datapenyedia/get_byid_kbli_nib/') ?>">
<input type="hidden" name="url_edit_kbli_nib" value="<?= base_url('datapenyedia/edit_kbli_nib') ?>">
<input type="hidden" name="url_hapus_kbli_nib" value="<?= base_url('datapenyedia/hapus_kbli_nib') ?>">
<!-- end link post nib -->


<!-- link post siup -->
<!-- siup -->
<input type="hidden" name="url_dekrip_siup" value="<?= base_url('datapenyedia/dekrip_siup') ?>">
<input type="hidden" name="url_encryption_siup" value="<?= base_url('datapenyedia/encryption_siup/') ?>">
<input type="hidden" name="url_download_siup" value="<?= base_url('datapenyedia/url_download_siup/') ?>">
<input type="hidden" value="<?= base_url('datapenyedia/add_siup') ?>" name="url_post_siup">
<!-- kbli siup-->
<input type="hidden" name="url_tambah_kbli_siup" value="<?= base_url('datapenyedia/tambah_kbli_siup') ?>">
<input type="hidden" name="url_table_kbli_siup" value="<?= base_url('datapenyedia/get_data_kbli_siup') ?>">
<input type="hidden" name="url_byid_kbli_siup" value="<?= base_url('datapenyedia/get_byid_kbli_siup/') ?>">
<input type="hidden" name="url_edit_kbli_siup" value="<?= base_url('datapenyedia/edit_kbli_siup') ?>">
<input type="hidden" name="url_hapus_kbli_siup" value="<?= base_url('datapenyedia/hapus_kbli_siup') ?>">
<!-- end link post nib -->


<!-- link post sbu -->
<!-- sbu -->
<input type="hidden" name="url_dekrip_sbu" value="<?= base_url('datapenyedia/dekrip_sbu') ?>">
<input type="hidden" name="url_encryption_sbu" value="<?= base_url('datapenyedia/encryption_sbu/') ?>">
<input type="hidden" name="url_download_sbu" value="<?= base_url('datapenyedia/url_download_sbu/') ?>">
<input type="hidden" value="<?= base_url('datapenyedia/add_sbu') ?>" name="url_post_sbu">
<!-- kbli sbu-->
<input type="hidden" name="url_tambah_kbli_sbu" value="<?= base_url('datapenyedia/tambah_kbli_sbu') ?>">
<input type="hidden" name="url_table_kbli_sbu" value="<?= base_url('datapenyedia/get_data_kbli_sbu') ?>">
<input type="hidden" name="url_byid_kbli_sbu" value="<?= base_url('datapenyedia/get_byid_kbli_sbu/') ?>">
<input type="hidden" name="url_edit_kbli_sbu" value="<?= base_url('datapenyedia/edit_kbli_sbu') ?>">
<input type="hidden" name="url_hapus_kbli_sbu" value="<?= base_url('datapenyedia/hapus_kbli_sbu') ?>">
<!-- end link post nib -->

<!-- link post siujk -->
<!-- siujk -->
<input type="hidden" name="url_dekrip_siujk" value="<?= base_url('datapenyedia/dekrip_siujk') ?>">
<input type="hidden" name="url_encryption_siujk" value="<?= base_url('datapenyedia/encryption_siujk/') ?>">
<input type="hidden" name="url_download_siujk" value="<?= base_url('datapenyedia/url_download_siujk/') ?>">
<input type="hidden" value="<?= base_url('datapenyedia/add_siujk') ?>" name="url_post_siujk">
<!-- kbli siujk-->
<input type="hidden" name="url_tambah_kbli_siujk" value="<?= base_url('datapenyedia/tambah_kbli_siujk') ?>">
<input type="hidden" name="url_table_kbli_siujk" value="<?= base_url('datapenyedia/get_data_kbli_siujk') ?>">
<input type="hidden" name="url_byid_kbli_siujk" value="<?= base_url('datapenyedia/get_byid_kbli_siujk/') ?>">
<input type="hidden" name="url_edit_kbli_siujk" value="<?= base_url('datapenyedia/edit_kbli_siujk') ?>">
<input type="hidden" name="url_hapus_kbli_siujk" value="<?= base_url('datapenyedia/hapus_kbli_siujk') ?>">
<!-- end link post nib -->


<!-- skdp -->
<input type="hidden" name="url_dekrip_skdp" value="<?= base_url('datapenyedia/dekrip_skdp') ?>">
<input type="hidden" name="url_encryption_skdp" value="<?= base_url('datapenyedia/encryption_skdp/') ?>">
<input type="hidden" name="url_download_skdp" value="<?= base_url('datapenyedia/url_download_skdp/') ?>">
<input type="hidden" value="<?= base_url('datapenyedia/add_skdp') ?>" name="url_post_skdp">
<!-- end skdp -->


<!-- lainnya -->
<input type="hidden" name="url_dekrip_lainnya" value="<?= base_url('datapenyedia/dekrip_lainnya') ?>">
<input type="hidden" name="url_encryption_lainnya" value="<?= base_url('datapenyedia/encryption_lainnya/') ?>">
<input type="hidden" name="url_download_lainnya" value="<?= base_url('datapenyedia/url_download_lainnya/') ?>">
<input type="hidden" value="<?= base_url('datapenyedia/add_lainnya') ?>" name="url_post_lainnya">
<!-- end lainnya -->