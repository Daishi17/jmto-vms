<script>
    setTimeout(function() {
        location.replace('https://eprocurement.jmto.co.id/')
    }, 4000);
</script>