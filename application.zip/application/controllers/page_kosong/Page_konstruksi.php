<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Page_konstruksi extends CI_Controller
{

	public function index()
	{
		$this->load->view('page_505/page_konstruksi');
	}
}
