<?php

namespace Box\Spout\Common\Exception;

/**
 * Class EncodingConversionException
 */
class EncodingConversionException extends SpoutException
{
}
